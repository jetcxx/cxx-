#include <stdio.h>

int main(int argc, char const *argv[])
{
    int num = 10;
    //static int a = num;   //c语言中 在编译阶段开辟空间 并赋值
    return 0;
}
