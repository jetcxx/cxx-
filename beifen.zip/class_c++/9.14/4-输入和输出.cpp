#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    int a = 100;
    double b = 4.2342342;
    float c = 456.123;
    char ch = 'z';
    cout<<"a = "<<a<<endl;
    cout<<"b = "<<b<<endl;
    //cout<<hex<<a<<endl;


    int a1,a2,a3;
    cin>>a1>>a2>>a3;
    //cout<<dec;
    cout<<"a1 = "<<a1<<endl;
    cout<<"a2 = "<<a2<<endl;
    cout<<"a3 = "<<a3<<endl;
    return 0;
}
