#include <iostream>

using namespace std;
int num = 100;
int main()
{
    int num = 200;
    cout<<"num = "<<::num<<endl;
    return 0;
}
