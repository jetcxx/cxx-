#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    register int i = 1;
    register int j = 2;
    &i;
    &j;
    for(i = 0;i < 10000;i++)
    {
        for(j = 0;j <1000;j++)
        {
            
        }
    }
    return 0;
}
