#!/bin/bash
cd ~
mkdir file-dir
mkdir dir-dir

