#ifndef _FUNCTION_  //防止头文件被重复包含
#define _FUNCTION_

#include <stdio.h>
/*
 *作者：
 *时间：
 *功能：
 *参数：
 *返回值：
 * */
void func();
/*
 *作者：
 *时间：
 *功能：
 *参数：
 *返回值：
 * */
int add(int x,int y);
int sub(int x,int y);
#endif
