#ifndef _FUNCTION_
#define _FUNCTION_

#include <stdio.h>


void func();


int add(int x,int y);

#endif
