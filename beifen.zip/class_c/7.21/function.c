#include "function.h"
void func()
{
    printf("hello world\n");
}
int add(int x,int y)
{
    return x + y;
}
