#include "function.h"
int main(int argc,const char *argv[])
{
    func();
    int a = 1,b = 2;
    printf("%d\n",add(a,b));
    return 0;
}
