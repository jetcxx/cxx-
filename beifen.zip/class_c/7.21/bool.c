#include <stdio.h>
#include <stdbool.h>
int main(int argc, const char *argv[])
{
bool b = 10;
printf("b = %d\n",b);
bool c = 0;
printf("c = %d\n",c);
bool d = 0.00000045;
printf("d = %d\n",d);
return 0;
}
