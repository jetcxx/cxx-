#include <stdio.h>
int main()
{
    char a;
    for(a = 'A';a <= 'Z';a++)
	printf("%c\t",a);
    return 0;
}
