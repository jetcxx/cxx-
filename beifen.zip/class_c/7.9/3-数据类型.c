#include <stdio.h>

int main(int argc, const char *argv[])
{
	//定义一个char类型的变量并赋值
	char a = 97;
	printf("a = %d\n",a);

	
	//定义一个short类型的变量并赋值
	short b  = 20000;
	printf("b = %d\n",b);
	
	//定义一个int类型的变量并赋值
	int c  = 213456789;

	printf("c = %d\n",c);

	//定义一个long类型的变量并赋值
	long d  = 213456789123899013;

	printf("d = %ld\n",d);
	return 0;
}
