#include <stdio.h>
int main()
{
    int i, sum = 0;
    printf("输入一个自然数:");
    scanf("%d",&i);
  //  sum = i*(i + 1)/2;
    printf("%d",sum = i*(i + 1)/2);
    return 0;
}
