#include <stdio.h>
#include <limits.h>
 
int main()
{
   printf("int 存储大小 : %lu \n", sizeof(int));
   printf("char 存储大小 : %lu \n", sizeof(char));
   printf("float 存储大小 : %lu \n", sizeof(float));
   printf("double 存储大小 : %lu \n", sizeof(double));
   
   return 0;
}
