#include <stdio.h>
int main(int argc, const char *argv[])
{
	int ch;
//	ch = getchar();
//	printf("ch = %c %d\n",ch,ch);

	int a,b,c;

	a = getchar();
	getchar();
	b = getchar();
	getchar();
	c = getchar();
	printf("a = %c %d\n",a,a);
	printf("b = %c %d\n",b,b);
	printf("c = %c %d\n",c,c);
	return 0;
}
