#include <stdio.h>
int main()
{
   char site[7] = {'R', 'U', 'N', 'O', 'O', 'B'};
 
   printf("菜鸟教程: %s\n", site );
 
   return 0;
}
