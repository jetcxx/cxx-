#include <stdio.h>

int main(int argc, const char *argv[])
{
	putchar('w');
	putchar('\n');

	putchar(120);
	putchar(10);

	int a = 'h';
	putchar(a);
	putchar(10);
	return 0;
}
