#include <stdio.h>
int main()
{
    char str[32];
    gets(str);
    printf("str = %s\n",str);
    return 0;
}
