#include <stdio.h>

int main(int argc, const char *argv[])
{
	int a = 100,b;
	b = a >= 10 && a <= 20;
	printf("b = %d\n",b);
}
