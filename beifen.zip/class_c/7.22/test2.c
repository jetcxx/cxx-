#include <stdio.h>
int main(int argc, const char *argv[])
{
printf("%ld\n",sizeof(int *));
printf("%ld\n",sizeof(char *));
printf("%ld\n",sizeof(double *));
printf("%ld\n",sizeof(short *));
printf("%ld\n",sizeof(float *));
return 0;
}
