#include<stdio.h>
int main()
{
    char a[] ="abcdefg";
    printf("%s\n",a);
    printf("%c\n",a[1]);
    printf("%d\n",a[1]);
    return 0;
}
