#include <stdio.h>
int main(int argc, char const *argv[])
{
    int s[8] = {1,1,3,3,5,6,7,7};
    int *p = s[1];
    int *q = s[8];
    return 0;
}
